package csc4330.lsutrition.Activities.utils;

/**
 * Created by Jay on 11/29/2017.
 */

public class Keys {

    public static final String KEY_CONTACTS = "Sheet1";
    public static final String KEY_RESTAURANTNAME = "RestaurantName";
    public static final String KEY_MENUITEM = "Item";
    public static final String KEY_TYPE = "Type";
    public static final String KEY_CALORIES = "Calories";

}
